===== Bow Rail Launcher Mod — Minecraft 1.21.4 =====

WHAT IT DOES:
When you shoot a bow, it automatically places a Rail block + TNT Minecart
from your hotbar directly in front of you.

REQUIREMENTS (to play):
- Minecraft 1.21.4
- Fabric Loader 0.16.9+
- Fabric API 0.114.0+1.21.4

===========================================================
HOW TO GET THE .JAR (FREE, works on Android!)
===========================================================

Step 1: Go to https://github.com and create a FREE account

Step 2: Click the "+" button → "New repository"
        Name it: bow-rail-launcher
        Set it to Public → click "Create repository"

Step 3: Upload ALL the files from this zip into the repository
        (drag and drop them on the GitHub page)

Step 4: GitHub will automatically start building your mod!
        Go to the "Actions" tab on your repository page.

Step 5: Wait 2-3 minutes for the build to finish (green checkmark)

Step 6: Click on the finished build → scroll down → click
        "bow-rail-launcher" under Artifacts → download your .jar!

Step 7: Put the .jar in your Minecraft mods folder. Done!

===========================================================
HOW TO USE IN GAME:
===========================================================
1. Put RAIL blocks and TNT MINECART in your hotbar
2. Pull back your bow and release to shoot
3. A rail + TNT minecart auto-places in front of you!

NOTE: You need BOTH Rail AND TNT Minecart in hotbar for it to work.

package com.bowraillauncher;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BowRailLauncherMod implements ModInitializer {
    public static final String MOD_ID = "bow_rail_launcher";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("BowRailLauncher Mod initialized!");
    }
}

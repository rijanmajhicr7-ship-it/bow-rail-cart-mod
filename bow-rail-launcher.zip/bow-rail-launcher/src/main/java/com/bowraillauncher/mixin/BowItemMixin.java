package com.bowraillauncher.mixin;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import net.minecraft.block.Blocks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(BowItem.class)
public class BowItemMixin {

    @Inject(method = "onStoppedUsing", at = @At("HEAD"))
    private void onBowReleased(ItemStack stack, World world, LivingEntity user, int remainingUseTicks, CallbackInfo ci) {
        // Only run on server side and for real players
        if (world.isClient()) return;
        if (!(user instanceof ServerPlayerEntity player)) return;

        // Make sure bow was actually pulled back enough (at least 3 ticks)
        int usedTicks = 72000 - remainingUseTicks;
        if (usedTicks < 3) return;

        // Search hotbar (slots 0-8) for Rail and TNT Minecart
        ItemStack railStack = null;
        ItemStack tntCartStack = null;

        for (int i = 0; i < 9; i++) {
            ItemStack hotbarStack = player.getInventory().getStack(i);
            if (railStack == null && hotbarStack.getItem() == Items.RAIL) {
                railStack = hotbarStack;
            }
            if (tntCartStack == null && hotbarStack.getItem() == Items.TNT_MINECART) {
                tntCartStack = hotbarStack;
            }
        }

        // Only proceed if both rail and TNT minecart are in hotbar
        if (railStack == null || tntCartStack == null) return;

        // Find the block position directly in front of the player at foot level
        Direction facing = player.getHorizontalFacing();
        BlockPos playerPos = player.getBlockPos();
        BlockPos placePos = playerPos.offset(facing);

        // Make sure the target position is air or replaceable
        if (!world.getBlockState(placePos).isAir() && !world.getBlockState(placePos).isReplaceable()) {
            return;
        }

        // Make sure there's a solid block below to support the rail
        BlockPos belowPos = placePos.down();
        if (!world.getBlockState(belowPos).isSolidBlock(world, belowPos)) {
            world.setBlockState(belowPos, Blocks.STONE.getDefaultState());
        }

        // Place the rail
        world.setBlockState(placePos, Blocks.RAIL.getDefaultState());
        railStack.decrement(1);

        // Spawn TNT minecart on top of the rail
        double cartX = placePos.getX() + 0.5;
        double cartY = placePos.getY();
        double cartZ = placePos.getZ() + 0.5;
        TntMinecartEntity tntCart = new TntMinecartEntity(world, cartX, cartY, cartZ);
        world.spawnEntity(tntCart);
        tntCartStack.decrement(1);
    }
}
